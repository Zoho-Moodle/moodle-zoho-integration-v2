<?php
/**
 * Event Observer for Moodle-Zoho Integration
 *
 * @package    local_moodle_zoho_sync
 * @copyright  2026 ABC Horizon
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace local_moodle_zoho_sync;

defined('MOODLE_INTERNAL') || die();

require_once(__DIR__ . '/data_extractor.php');
require_once(__DIR__ . '/webhook_sender.php');

class observer {
    
    /**
     * Handle user created event
     * 
     * @param \core\event\user_created $event
     */
    public static function user_created(\core\event\user_created $event) {
        // Check if user sync is enabled
        if (!get_config('local_moodle_zoho_sync', 'enable_user_sync')) {
            return;
        }

        try {
            // Extract user data
            $extractor = new data_extractor();
            $user_data = $extractor->extract_user_data($event->objectid);

            if (!$user_data) {
                self::log_error('Failed to extract user data for user ID: ' . $event->objectid);
                return;
            }

            // Send webhook
            $sender = new webhook_sender();
            $response = $sender->send_user_created($user_data);

            self::log_debug('User created webhook sent', [
                'user_id' => $event->objectid,
                'response' => $response
            ]);

        } catch (\Exception $e) {
            self::log_error('Error in user_created observer: ' . $e->getMessage());
        }
    }

    /**
     * Handle user updated event
     * 
     * @param \core\event\user_updated $event
     */
    public static function user_updated(\core\event\user_updated $event) {
        // Check if user sync is enabled
        if (!get_config('local_moodle_zoho_sync', 'enable_user_sync')) {
            return;
        }

        try {
            // Extract user data
            $extractor = new data_extractor();
            $user_data = $extractor->extract_user_data($event->objectid);

            if (!$user_data) {
                self::log_error('Failed to extract user data for user ID: ' . $event->objectid);
                return;
            }

            // Send webhook
            $sender = new webhook_sender();
            $response = $sender->send_user_updated($user_data);

            self::log_debug('User updated webhook sent', [
                'user_id' => $event->objectid,
                'response' => $response
            ]);

        } catch (\Exception $e) {
            self::log_error('Error in user_updated observer: ' . $e->getMessage());
        }
    }

    /**
     * Handle enrollment created event
     * 
     * @param \core\event\user_enrolment_created $event
     */
    public static function enrollment_created(\core\event\user_enrolment_created $event) {
        // Check if enrollment sync is enabled
        if (!get_config('local_moodle_zoho_sync', 'enable_enrollment_sync')) {
            return;
        }

        try {
            // Extract enrollment data
            $extractor = new data_extractor();
            $enrollment_data = $extractor->extract_enrollment_data($event->objectid);

            if (!$enrollment_data) {
                self::log_error('Failed to extract enrollment data for enrollment ID: ' . $event->objectid);
                return;
            }

            // Send webhook
            $sender = new webhook_sender();
            $response = $sender->send_enrollment_created($enrollment_data);

            self::log_debug('Enrollment created webhook sent', [
                'enrollment_id' => $event->objectid,
                'response' => $response
            ]);

        } catch (\Exception $e) {
            self::log_error('Error in enrollment_created observer: ' . $e->getMessage());
        }
    }

    /**
     * Handle grade updated event
     * 
     * @param \core\event\user_graded $event
     */
    public static function grade_updated(\core\event\user_graded $event) {
        // Check if grade sync is enabled
        if (!get_config('local_moodle_zoho_sync', 'enable_grade_sync')) {
            return;
        }

        try {
            // Extract grade data
            $extractor = new data_extractor();
            $grade_data = $extractor->extract_grade_data($event->objectid);

            if (!$grade_data) {
                self::log_error('Failed to extract grade data for grade ID: ' . $event->objectid);
                return;
            }

            // Send webhook
            $sender = new webhook_sender();
            $response = $sender->send_grade_updated($grade_data);

            self::log_debug('Grade updated webhook sent', [
                'grade_id' => $event->objectid,
                'response' => $response
            ]);

        } catch (\Exception $e) {
            self::log_error('Error in grade_updated observer: ' . $e->getMessage());
        }
    }

    /**
     * Log error message
     * 
     * @param string $message
     */
    private static function log_error($message) {
        error_log('[Moodle-Zoho Sync ERROR] ' . $message);
    }

    /**
     * Log debug message if debug is enabled
     * 
     * @param string $message
     * @param array $context
     */
    private static function log_debug($message, $context = []) {
        if (get_config('local_moodle_zoho_sync', 'enable_debug')) {
            error_log('[Moodle-Zoho Sync DEBUG] ' . $message . ' ' . json_encode($context));
        }
    }
}
