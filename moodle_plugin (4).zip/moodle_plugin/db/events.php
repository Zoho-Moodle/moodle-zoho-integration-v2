<?php
/**
 * Event observers for Moodle-Zoho Integration Plugin
 *
 * @package    local_moodle_zoho_sync
 * @copyright  2026 ABC Horizon
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$observers = [
    // User created event
    [
        'eventname' => '\core\event\user_created',
        'callback'  => '\local_moodle_zoho_sync\observer::user_created',
    ],
    
    // User updated event
    [
        'eventname' => '\core\event\user_updated',
        'callback'  => '\local_moodle_zoho_sync\observer::user_updated',
    ],
    
    // User enrollment created
    [
        'eventname' => '\core\event\user_enrolment_created',
        'callback'  => '\local_moodle_zoho_sync\observer::enrollment_created',
    ],
    
    // User graded event
    [
        'eventname' => '\core\event\user_graded',
        'callback'  => '\local_moodle_zoho_sync\observer::grade_updated',
    ],
];
