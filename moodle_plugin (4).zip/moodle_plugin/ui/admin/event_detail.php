<?php
/**
 * Event Detail page for Moodle-Zoho Integration Plugin
 *
 * @package    local_moodle_zoho_sync
 * @copyright  2026 ABC Horizon
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

require_once(__DIR__ . '/../../../../config.php');
require_once($CFG->libdir . '/adminlib.php');

// Require login and admin capabilities.
require_login();
admin_externalpage_setup('local_moodle_zoho_sync_logs');

$context = context_system::instance();
require_capability('local/moodle_zoho_sync:manage', $context);

// Page parameters.
$eventid = required_param('id', PARAM_INT);

// Page setup.
$PAGE->set_url('/local/moodle_zoho_sync/ui/admin/event_detail.php', ['id' => $eventid]);
$PAGE->set_context($context);
$PAGE->set_title('Event Details');
$PAGE->set_heading('Event Details');

// Get event from database.
global $DB;
$event = $DB->get_record('local_mzi_event_log', ['id' => $eventid], '*', MUST_EXIST);

// Render page.
echo $OUTPUT->header();
echo $OUTPUT->heading('Event Details: ' . substr($event->event_id, 0, 8));

// Back button.
echo html_writer::link(
    new moodle_url('/local/moodle_zoho_sync/ui/admin/event_logs.php'),
    '← Back to Event Logs',
    ['class' => 'btn btn-secondary mb-3']
);

// Event details card.
echo html_writer::start_div('card');
echo html_writer::start_div('card-body');

// Basic info.
echo html_writer::tag('h5', 'Basic Information', ['class' => 'card-title']);
$table = new html_table();
$table->attributes['class'] = 'table table-bordered';
$table->data = [
    ['<strong>Event ID</strong>', $event->event_id],
    ['<strong>Event Type</strong>', $event->event_type],
    ['<strong>Status</strong>', $event->status],
    ['<strong>Retry Count</strong>', $event->retry_count],
    ['<strong>HTTP Status</strong>', $event->http_status ?? 'N/A'],
    ['<strong>Moodle Event ID</strong>', $event->moodle_event_id ?? 'N/A'],
    ['<strong>Created</strong>', userdate($event->timecreated, '%Y-%m-%d %H:%M:%S')],
    ['<strong>Modified</strong>', userdate($event->timemodified, '%Y-%m-%d %H:%M:%S')],
    ['<strong>Processed</strong>', $event->timeprocessed ? userdate($event->timeprocessed, '%Y-%m-%d %H:%M:%S') : 'Not yet'],
];
echo html_writer::table($table);

// Event data.
if ($event->event_data) {
    echo html_writer::tag('h5', 'Event Data (JSON)', ['class' => 'card-title mt-4']);
    $eventdata = json_decode($event->event_data, true);
    if ($eventdata) {
        echo html_writer::tag('pre', json_encode($eventdata, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE), 
            ['class' => 'bg-light p-3', 'style' => 'max-height: 400px; overflow-y: auto;']);
    } else {
        echo html_writer::div('Invalid JSON data', 'alert alert-warning');
    }
}

// Error message.
if ($event->last_error) {
    echo html_writer::tag('h5', 'Last Error Message', ['class' => 'card-title mt-4']);
    echo html_writer::div($event->last_error, 'alert alert-danger');
}

echo html_writer::end_div(); // card-body
echo html_writer::end_div(); // card

echo $OUTPUT->footer();
