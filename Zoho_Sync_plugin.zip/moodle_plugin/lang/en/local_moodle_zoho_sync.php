<?php
/**
 * Language strings for Moodle-Zoho Integration Plugin
 *
 * @package    local_moodle_zoho_sync
 * @copyright  2026 ABC Horizon
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

// Plugin name
$string['pluginname'] = 'Moodle-Zoho Integration';

// Settings page
$string['backend_url'] = 'Backend API URL';
$string['backend_url_desc'] = 'The URL of the Backend API server (e.g., http://localhost:8001 or https://your-domain.com)';

$string['api_token'] = 'API Token';
$string['api_token_desc'] = 'Authentication token for Backend API (leave empty if not required)';

$string['enable_user_sync'] = 'Enable User Sync';
$string['enable_user_sync_desc'] = 'Send user created/updated events to Backend';

$string['enable_enrollment_sync'] = 'Enable Enrollment Sync';
$string['enable_enrollment_sync_desc'] = 'Send enrollment created events to Backend';

$string['enable_grade_sync'] = 'Enable Grade Sync';
$string['enable_grade_sync_desc'] = 'Send grade updated events to Backend';

$string['enable_debug'] = 'Enable Debug Logging';
$string['enable_debug_desc'] = 'Log detailed debug information (recommended for testing only)';

$string['ssl_verify'] = 'Verify SSL Certificate';
$string['ssl_verify_desc'] = 'Verify SSL certificate when connecting to Backend API (disable only for development)';

// Privacy
$string['privacy:metadata'] = 'The Moodle-Zoho Integration plugin sends user data to an external Backend API for synchronization with Zoho CRM.';
$string['privacy:metadata:user_data'] = 'User information (name, email, phone) is sent to the Backend API';
$string['privacy:metadata:enrollment_data'] = 'Course enrollment information is sent to the Backend API';
$string['privacy:metadata:grade_data'] = 'Grade information is sent to the Backend API';
