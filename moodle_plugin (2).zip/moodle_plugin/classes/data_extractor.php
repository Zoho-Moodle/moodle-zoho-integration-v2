<?php
/**
 * Data Extractor for Moodle-Zoho Integration
 * Extracts data from Moodle database tables
 *
 * @package    local_moodle_zoho_sync
 * @copyright  2026 ABC Horizon
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

namespace local_moodle_zoho_sync;

defined('MOODLE_INTERNAL') || die();

class data_extractor {

    /**
     * Extract user data from mdl_user table
     * 
     * @param int $userid
     * @return array|null User data or null if not found
     */
    public function extract_user_data($userid) {
        global $DB;

        try {
            $user = $DB->get_record('user', ['id' => $userid]);

            if (!$user) {
                return null;
            }

            // Skip deleted or suspended users
            if ($user->deleted == 1 || $user->suspended == 1) {
                return null;
            }

            // Determine user role (student or teacher)
            $role = $this->get_user_primary_role($userid);

            return [
                'userid' => (int)$user->id,
                'username' => $user->username,
                'email' => $user->email,
                'firstname' => $user->firstname,
                'lastname' => $user->lastname,
                'phone1' => $user->phone1 ?? '',
                'phone2' => $user->phone2 ?? '',
                'city' => $user->city ?? '',
                'country' => $user->country ?? '',
                'role' => $role,
                'timecreated' => (int)$user->timecreated,
                'timemodified' => (int)$user->timemodified,
            ];

        } catch (\Exception $e) {
            error_log('[Data Extractor ERROR] extract_user_data: ' . $e->getMessage());
            return null;
        }
    }

    /**
     * Extract enrollment data from mdl_user_enrolments table
     * 
     * @param int $enrolmentid
     * @return array|null Enrollment data or null if not found
     */
    public function extract_enrollment_data($enrolmentid) {
        global $DB;

        try {
            // Get enrollment record with enrolment method details
            $sql = "SELECT ue.id, ue.userid, ue.status, ue.timestart, ue.timeend,
                           ue.timecreated, ue.timemodified,
                           e.courseid, e.enrol as enrol_method,
                           c.fullname as course_name, c.shortname as course_shortname
                    FROM {user_enrolments} ue
                    JOIN {enrol} e ON e.id = ue.enrolid
                    JOIN {course} c ON c.id = e.courseid
                    WHERE ue.id = :enrolmentid";

            $enrollment = $DB->get_record_sql($sql, ['enrolmentid' => $enrolmentid]);

            if (!$enrollment) {
                return null;
            }

            return [
                'enrollment_id' => (int)$enrollment->id,
                'userid' => (int)$enrollment->userid,
                'courseid' => (int)$enrollment->courseid,
                'course_name' => $enrollment->course_name,
                'course_shortname' => $enrollment->course_shortname,
                'status' => (int)$enrollment->status, // 0 = active, 1 = suspended
                'enrol_method' => $enrollment->enrol_method,
                'timestart' => (int)$enrollment->timestart,
                'timeend' => (int)$enrollment->timeend,
                'timecreated' => (int)$enrollment->timecreated,
                'timemodified' => (int)$enrollment->timemodified,
            ];

        } catch (\Exception $e) {
            error_log('[Data Extractor ERROR] extract_enrollment_data: ' . $e->getMessage());
            return null;
        }
    }

    /**
     * Extract grade data from mdl_grade_grades table
     * 
     * @param int $gradeid
     * @return array|null Grade data or null if not found
     */
    public function extract_grade_data($gradeid) {
        global $DB;

        try {
            // Get grade with item details
            $sql = "SELECT gg.id, gg.userid, gg.itemid, gg.finalgrade, 
                           gg.timecreated, gg.timemodified,
                           gi.itemname, gi.itemtype, gi.itemmodule,
                           gi.grademax, gi.grademin,
                           c.id as courseid, c.fullname as course_name
                    FROM {grade_grades} gg
                    JOIN {grade_items} gi ON gi.id = gg.itemid
                    LEFT JOIN {course} c ON c.id = gi.courseid
                    WHERE gg.id = :gradeid";

            $grade = $DB->get_record_sql($sql, ['gradeid' => $gradeid]);

            if (!$grade || is_null($grade->finalgrade)) {
                return null;
            }

            // Fetch user data (was missing).
            $user = $DB->get_record('user', ['id' => $grade->userid], 'id,username,email');
            if (!$user) {
                return null;
            }

            // Normalize grade to 0-100 scale
            $normalized_grade = 0;
            if ($grade->grademax > 0) {
                $normalized_grade = (($grade->finalgrade - $grade->grademin) / 
                                    ($grade->grademax - $grade->grademin)) * 100;
            }

            return [
                'grade_id' => (int)$grade->id,
                'userid' => (int)$grade->userid,
                'itemid' => (int)$grade->itemid,
                'item_name' => $grade->itemname ?? '',
                'item_type' => $grade->itemtype,
                'item_module' => $grade->itemmodule ?? '',
                'courseid' => (int)$grade->courseid,
                'course_name' => $grade->course_name ?? '',
                'finalgrade' => round($normalized_grade, 2), // 0-100 scale
                'raw_grade' => (float)$grade->finalgrade,
                'grademax' => (float)$grade->grademax,
                'grademin' => (float)$grade->grademin,
                'timecreated' => (int)$grade->timecreated,
                'timemodified' => (int)$grade->timemodified,
            ];

        } catch (\Exception $e) {
            error_log('[Data Extractor ERROR] extract_grade_data: ' . $e->getMessage());
            return null;
        }
    }

    /**
     * Get user's primary role (student or teacher)
     * 
     * @param int $userid
     * @return string 'student', 'teacher', or 'other'
     */
    private function get_user_primary_role($userid) {
        global $DB;

        try {
            // Get user's role assignments
            $sql = "SELECT DISTINCT r.shortname
                    FROM {role_assignments} ra
                    JOIN {role} r ON r.id = ra.roleid
                    WHERE ra.userid = :userid
                    ORDER BY FIELD(r.shortname, 'teacher', 'editingteacher', 'student') DESC
                    LIMIT 1";

            $role = $DB->get_field_sql($sql, ['userid' => $userid]);

            if (!$role) {
                return 'other';
            }

            // Map Moodle roles to simplified roles
            if (in_array($role, ['student', 'learner'])) {
                return 'student';
            } elseif (in_array($role, ['teacher', 'editingteacher', 'instructor'])) {
                return 'teacher';
            } else {
                return 'other';
            }

        } catch (\Exception $e) {
            error_log('[Data Extractor ERROR] get_user_primary_role: ' . $e->getMessage());
            return 'other';
        }
    }
}
