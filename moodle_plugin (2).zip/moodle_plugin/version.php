<?php
/**
 * Version details for Moodle-Zoho Integration Plugin
 *
 * @package    local_moodle_zoho_sync
 * @copyright  2026 ABC Horizon
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$plugin->component = 'local_moodle_zoho_sync';
$plugin->version   = 2026020101;        // YYYYMMDDXX format - P1 fixes applied
$plugin->requires  = 2022041900;        // Requires Moodle 4.0+
$plugin->maturity  = MATURITY_STABLE;
$plugin->release   = '3.0.1';           // Version 3.0.1 - P1 fixes
