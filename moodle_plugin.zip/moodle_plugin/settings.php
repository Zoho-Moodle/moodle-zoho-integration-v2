<?php
/**
 * Admin settings for Moodle-Zoho Integration Plugin
 *
 * @package    local_moodle_zoho_sync
 * @copyright  2026 ABC Horizon
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

if ($hassiteconfig) {
    $settings = new admin_settingpage('local_moodle_zoho_sync', 
        get_string('pluginname', 'local_moodle_zoho_sync'));

    // Backend API URL
    $settings->add(new admin_setting_configtext(
        'local_moodle_zoho_sync/backend_url',
        get_string('backend_url', 'local_moodle_zoho_sync'),
        get_string('backend_url_desc', 'local_moodle_zoho_sync'),
        'http://localhost:8001',
        PARAM_URL
    ));

    // API Token
    $settings->add(new admin_setting_configtext(
        'local_moodle_zoho_sync/api_token',
        get_string('api_token', 'local_moodle_zoho_sync'),
        get_string('api_token_desc', 'local_moodle_zoho_sync'),
        '',
        PARAM_TEXT
    ));

    // Enable User Sync
    $settings->add(new admin_setting_configcheckbox(
        'local_moodle_zoho_sync/enable_user_sync',
        get_string('enable_user_sync', 'local_moodle_zoho_sync'),
        get_string('enable_user_sync_desc', 'local_moodle_zoho_sync'),
        1
    ));

    // Enable Enrollment Sync
    $settings->add(new admin_setting_configcheckbox(
        'local_moodle_zoho_sync/enable_enrollment_sync',
        get_string('enable_enrollment_sync', 'local_moodle_zoho_sync'),
        get_string('enable_enrollment_sync_desc', 'local_moodle_zoho_sync'),
        1
    ));

    // Enable Grade Sync
    $settings->add(new admin_setting_configcheckbox(
        'local_moodle_zoho_sync/enable_grade_sync',
        get_string('enable_grade_sync', 'local_moodle_zoho_sync'),
        get_string('enable_grade_sync_desc', 'local_moodle_zoho_sync'),
        1
    ));

    // Enable Debug Logging
    $settings->add(new admin_setting_configcheckbox(
        'local_moodle_zoho_sync/enable_debug',
        get_string('enable_debug', 'local_moodle_zoho_sync'),
        get_string('enable_debug_desc', 'local_moodle_zoho_sync'),
        0
    ));

    // SSL Verification
    $settings->add(new admin_setting_configcheckbox(
        'local_moodle_zoho_sync/ssl_verify',
        get_string('ssl_verify', 'local_moodle_zoho_sync'),
        get_string('ssl_verify_desc', 'local_moodle_zoho_sync'),
        1
    ));

    $ADMIN->add('localplugins', $settings);
}
